const { createUser,getAllUsers,getUserById,userUpdate,userDelete } = require('../controllers/IndexController.js');
const express = require('express');
const router = express.Router();
router.post('/user',createUser);
router.get('/user',getAllUsers);
router.get('/user/:id',getUserById);
router.patch('/user',userUpdate);
router.delete('/user/:id',userDelete);

module.exports = router;




// const express = require('express');
// const router = express.Router();
// const controller = require('../controllers/IndexController');
// //const pool = require('../database');

// router.get('/user',res.send(controller.IndexController.user));
// router.get('/user/:id',controller.IndexController.user_id);

// module.exports.router = router;