const { create,getAllUsers,getUserById,userUpdate,userDelete } = require('../models.js');
const { genSaltSync,hashSync } = require('bcrypt');
module.exports = {
    createUser : (req,res)=>{
        const body =req.body;
        // const salt = genSaltSync(10);
        // body.phone=hashSync(body.phone,salt);
        create(body,(results,error)=>{
            if(error){
                console.log(error);
                return res.status(500).json({
                    success:0,
                    message:"Database connection error"
                });
            }
            return res.status(200).json({
                success:1,
                message:"data successfully loaded",
                data : results
            })
        });
    },
    getAllUsers : (req,res)=>{
        getAllUsers((results,error)=>{
            if(error){
                console.log(error);
                return res.status(404).json({
                    success:0,
                    message:"Something went wrong :("
                });
            }
            return res.status(200).json({
                success: 1,
                message: results
            });
        })
    },
    getUserById:(req,res)=>{
        let id = req.params.id;
        getUserById(id,(results,error)=>{
            if(error){
                console.log(error);
                return;
            }
            if(!results){
                return res.status(404).json({
                    success: 0,
                    message: "Record Not Found"
                })
            }
            return res.status(200).json({
                success:1,
                message:results
            })
        })
    },
    userUpdate:(req,res)=>{
        const body=req.body;
        userUpdate(body,(results,error)=>{
            if(error){
                console.log(error);
                return;
            }
            if(!results){
                return res.json({
                    success: 0,
                    message: "Insufficient data"
                })
            }
            return res.status(200).json({
                success:1,
                message:"Data Updated",
                data: results
            })
        })
    },
    userDelete:(req,res)=>{
        let id = req.params.id;
        userDelete(id,(results,error)=>{
            if(error){
                console.log(error);
                return;
            }
            if(!results){
                return res.status(404).json({
                    success: 0,
                    message: "Record Not Found"
                })
            }
            return res.status(200).json({
                success:1,
                message: "Record Deleted"
            })
        })
    }
}














// var data = require('../database');
// var model = require('../models.js');
// class IndexController{
//     static user(req,res){
//         res.send(model.DataModel.user(req,res));
//     }
//     static user_id(req,res){
//         model.DataModel.user_id(req,res);
//     }
// }

// module.exports.IndexController=IndexController;